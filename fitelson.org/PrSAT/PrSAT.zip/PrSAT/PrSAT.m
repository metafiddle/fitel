(* ::Package:: *)

Off[General::compat];
Notation`AutoLoadNotationPalette = False;
Needs["Notation`"];
Off[NMinimize::"nnum"];
Off[General::spell1];
Off[N::meprec];
Off[Rule::rhs];
Off[Nonreal::warning];
Off[Intersection::"heads"];
Off[Union::"heads"];
Off[Complement::"heads"];
Off[Solve::"svars"];
Off[General::spell1];
Off[Rule::rhs];
Off[GreaterEqual::"nord"];
Off[LessEqual::"nord"];
Off[Power::"infy"];
Off[Maximize::"wksol"];
Off[Minimize::"wksol"];
Off[Maximize::"natt"];
Off[Max::"nord"];
Off[Part::"partw"];
Off[Simplify::"cas"];

Unprotect[
    All,
    EvaluateProbability,
    Last,
    NotRegular,
    PrSAT,
    Probabilities,
    Constraints,
    RunQuietly,
    Regular,
    ShowStages,
    Verify,
    AlgebraicForm,
    TruthTable,
    PrKey,
    PrReduce,
	PrReduceFast,
	PrFullSimplify,
    PrSolve,
    PrRange,
	PrGraph,
	VARS,
	pr,
	prR,
	PR,
	PRR
    ];

Notation[ParsedBoxWrapper[\(\[Not]\[Alpha]_\)]\[DoubleLongLeftRightArrow]ParsedBoxWrapper[\(Not[\[Alpha]_]\)]];
Notation[ParsedBoxWrapper[\(Pr[\(\[Alpha]_|\[Beta]_\)]\)] \[DoubleLongLeftRightArrow] ParsedBoxWrapper[
     \(\(Pr[\(\[Alpha]_&&\[Beta]_\)]\)\/\(Pr[\[Beta]_]\)\)
     ]]; 
Pr[{}]=0;
Pr[\[Alpha]_List]:=Plus@@Flatten[\[Alpha]];

cleanupRules={Rule->List,And->List,Power->List,Implies->List,
      Not->List,Or->List,Plus->List,Times->List,Log->List,
      Pr->List,Equal->List,Unequal->List,Less->List,
      LessEqual->List,Greater->List,GreaterEqual->List,
      False->{},True->{},\[Infinity]->{},If->List,
      Min->List,Max->List,Inequality->List};

ExtractVariables[l_]:=Module[{t},
      t={l}//.cleanupRules//Flatten//Union;
      Return[
        Select[Select[t,Not[NumericQ[#]]&],!(#===List)&]
        ]
      ];

CrossMultiply[l_,c_]:=Module[
      {d,ds,test,t},
      l//. {
          (h:Equal|Unequal|Less|Greater|LessEqual|GreaterEqual)[
              w__]:>
            (ds=Denominator[Together[{w}]];
              d=Times@@ds;
              test=Simplify[d<0,c];
              If[!AtomQ[test],test=Simplify[d<=0,c]];
              If[test===True,
                d=-d,
                If[test=!=False,
                  d=Times@@((t=Simplify[#<0,c];
                              If[!AtomQ[t],t=Simplify[#<=0,c]];
                              If[t===True,-#,
                                If[t=!=False,1,#]])&/@ds)
                  ]
                ];
              h@@Simplify[({w}*d)])
          }
      ];

bootstrap[v_] := Thread[ExtractVariables[v] -> (ExtractVariables[v] //. v)]; 

Defns[set_]:=Union[set,(#1>0&)/@(1/#1&)/@Select[Level[set,{0,Infinity}], MatchQ[#1,1/(y_)]&]];

lfix[set_] := Module[{V, s1, s2}, V = ExtractVariables[set][[1]]; 
     s1 = set /. Pr[(x_) && (y_)]/Pr[y_] :> If[LogicalExpand[y] === False && 
          LogicalExpand[x] === True, Pr[(V ||  !V) && (V &&  !V)]/
          Pr[V &&  !V], If[LogicalExpand[y] === True && LogicalExpand[x] === 
            True, 1, If[LogicalExpand[y] === False && LogicalExpand[x] === 
             False, Pr[(V &&  !V) && (V &&  !V)]/Pr[V &&  !V], 
           If[LogicalExpand[y] === True && LogicalExpand[x] === False, 0, 
            Pr[LogicalExpand[x] && LogicalExpand[y]]/
             Pr[LogicalExpand[y]]]]]]; 
     s2 = s1 /. Pr[x_] :> If[ !MatchQ[x, V &&  !V] && 
           !LogicalExpand[x] === False &&  !MatchQ[x, V ||  !V] && 
           !LogicalExpand[x] === True, Pr[LogicalExpand[x]], 
         If[MatchQ[x, V ||  !V] || LogicalExpand[x] === True, Pr[V ||  !V], 
          If[MatchQ[x, V &&  !V] || LogicalExpand[x] === False, Pr[V &&  !V], 
           Pr[x]]]]]; 

RandomModel[n_]:=Module[{X,Y,Z},
      Y=Sort[Table[Random[],{n-1}]];
      Z[1]=Part[Y,1];
      Z[i_]:=Z[i]=(Part[Y,i]-Part[Y,i-1]);
      Z[n]=1-Sum[Z[i],{i,1,n-1}];
      Table[Z[i],{i,1,n}]
      ];

ExtractAtom[event_,
    ruleset_]:=(If[
            MemberQ[#[[1]],
              event],{#[[2]]},{}]&/@
        ruleset)//Flatten

AssociateEventsWithAtoms[theEventSet_]:=Module[{vennDiagram,omega,ruleset},
vennDiagram=Subsets[Sort[theEventSet]];
omega=Table[Subscript[\[DoubleStruckA], j],{j,1,Length[vennDiagram]}];
ruleset=MapThread[
#1->#2&,
{vennDiagram,omega}
];
Return[
Join[
{\[CapitalOmega]->omega},
{NullEvent->{{}}}/.ruleset,
#->ExtractAtom[#,ruleset]&/@theEventSet
]
]
]

NotRegular[variableSet_,omega_,tol_]:=
    If[variableSet==omega,
      Join[0<=#<=1&/@variableSet,{Plus@@variableSet==1}],
      Join[0<=#<=1&/@variableSet,{Plus@@variableSet<=1}]
      ];

Off[General::spell1];
Off[N::meprec];
Off[Rule::rhs];
Off[Nonreal::warning];
Regular[variableSet_,omega_, tol_]:=
    If[variableSet==omega,
      Join[tol<#<1&/@variableSet,{Plus@@variableSet==1}],
      Join[tol<#<1&/@
          variableSet,{Plus@@variableSet<
            1-tol*(Length[omega]-Length[variableSet])}]
      ];
Off[Intersection::"heads"];
Off[Union::"heads"];
Off[Complement::"heads"];
Off[Solve::"svars"];
Off[General::spell1];
Off[Rule::rhs];
Off[GreaterEqual::"nord"];
Off[LessEqual::"nord"];
Off[Power::"infy"];

VARS[varset_]:=Table[Subscript[\[DoubleStruckA], j],{j,1,2^Length[varset]}];
pr[varset_]:=And@@((0<=#<=1)&/@VARS[varset])&&Last[VARS[varset]]==1-Plus@@Drop[VARS[varset],-1];
prR[varset_]:=Flatten[{((0<#<1)&/@VARS[varset]),Last[VARS[varset]]==1-Plus@@Drop[VARS[varset],-1]}];
PR[expr_]:=And@@(0<=#<=1&/@ExtractVariables[expr])&&(Plus@@ExtractVariables[expr]<=1);
PRR[expr_]:=And@@(0<#<1&/@ExtractVariables[expr])&&(Plus@@ExtractVariables[expr]<=1);

NonrealRule = {Complex[x_, _?(Chop[#1] == 0 & )] :> x, 
    Complex[_, _?(Chop[#1] =!= 0 & )] -> Nonreal, 
    (Plus | Times | Minus | Subtract | Sqrt | Power | PowerMod | Abs | Exp | Log | Sin | 
       Cos | Tan | Cot | Sec | Csc | ArcSin | ArcCos | ArcTan | ArcCot | ArcSec | 
       ArcCsc | Floor | Ceiling | Round | Mod | Quotient | Prime | Min | Max | LCM | 
       GCD | Random | Rationalize)[___, Nonreal, ___] :> Nonreal};

AlgebraicForm[expr1_,varset_]:=Module[{expr,eventSets,omega,atomsInNonNullEvents,nullEventRule},
expr=lfix[expr1];
eventSets=AssociateEventsWithAtoms[Sort[varset]];
omega=\[CapitalOmega]/.eventSets;
atomsInNonNullEvents=Complement[omega,NullEvent/.eventSets];
nullEventRule=(NullEvent/.eventSets)[[1]]->1-Plus@@atomsInNonNullEvents/.eventSets;
expr/.eventSets//.
{(x_List)&&(y_List):>Intersection[x,y],(x_List)||(y_List):>Union[x,y],!(x_List):>Complement[omega,x]}//.nullEventRule]

TruthTable[mod_]:=Module[{vars,interps,PrAss,states,atoms,profile,ttrow,myelem},
myelem[s_,S_]:=myelem[s,S]=Or@@(#1===s&)/@S;
vars[model_]:=vars[model]=Take[Flatten[model]//.(x_->y_)->x,Length[model[[1]]]-1];
interps[model_]:=interps[model]=Flatten[Outer[List,Sequence@@Table[{True,False},{Length[vars[model]]}]],Length[vars[model]]-1];
PrAss[model_]:=Last[model];
states[model_]:=states[model]=Last[Select[Flatten[model]//.(x_->y_)->y,ListQ]];atoms[model_]:=Drop[Select[Flatten[model]//.(x_->y_)->y,ListQ],-1];
profile[s_,model_]:=profile[s,model]=myelem[s,#1]&/@atoms[model];
ttrow[n_,model_]:=ttrow[n,model]=Select[states[model],profile[#1,model]===interps[model][[n]]&];
Grid[Join[{Join[vars[mod],{"var"},{"Pr"}]},Table[Join[interps[mod][[i]],Sequence[ttrow[i,mod],ttrow[i,mod]//.PrAss[mod]]]//.{True->T,False->F},{i,1,Length[interps[mod]]}]],Dividers->Center]];

Options[PrSAT]={Probabilities->NotRegular,Constraints->{},
      RunQuietly->True,Margin->1.*^-6,RegMargin->1.*^-3,
      Seed->{},SearchAttempts->3,Method->"NM",Complete->True,
      BypassSearch->False};

ExtractEquations[l_]:=Select[l,MatchQ[#,x__==y__]&];

ExtractInequalities[l_]:=Complement[l,ExtractEquations[l]];

ZeroJump[z_,t_]:=If[z<=t,-1000.,z];

Gobble[e___]:=Null;

PrSAT::err1="The specified option for Probabilities was neither Regular nor NotRegular. Defaulting to NotRegular.";\

PrSAT::srchfail="Search phase failed; attempting FindInstance";
PrSAT::badmeth="Unrecognized search method.  Valid choices are NM and Random.";

PrSAT[l0_,opts___]:=Module[
      {eventVariables,eventSets,equations,inequalities,nullEventRule,vars,
        omega,atomsInNonNullEvents,systemToInstantiate,nextSystem,
        solutionLists,l1,l2,PrintLog,runquiet,constrnts,margin,
        prc,sol,sol1,ineqs1,model1,model,modelb,newmodel,ms,m,i,modelvars, 
        nonmodelvars, nonmodelvarrules, sysEqs, sysIneqs,sysCons,f, seed,
        repeats,method,findinst,regmargin,sys,realonly,solve,solved,initPoints,
        initRanges,testmodel,diff,ratmodel,nonmodelvarvals,bigmodelvars,
        bigmodelvarvals,bigmodelvarrules,regmodelvars,regmodelvarvals,
        regmodelvarrules,negmodelvars,negmodelvarvals,negmodelvarrules,
        min,certificate,bypass}, 
      Catch[prc=
          Probabilities/.{opts}/.Options[PrSAT];
        (******SET OPTIONS********)
        If[prc===NotRegular,
          prc=NotRegular,
          If[prc===Regular,
            prc=Regular,
            Message[PrSAT::err1];
            prc=NotRegular
            ]
          ];
        constrnts=
          Constraints/.{opts}/.Options[PrSAT];
        runquiet=RunQuietly/.{opts}/.Options[PrSAT];
        margin=Margin/.{opts}/.Options[PrSAT];
        seed=Seed/.{opts}/.Options[PrSAT];
        repeats=SearchAttempts/.{opts}/.Options[PrSAT];
        method=Method/.{opts}/.Options[PrSAT];
        findinst=Complete/.{opts}/.Options[PrSAT];
        bypass=BypassSearch/.{opts}/.Options[PrSAT];
        If[seed==={},
          seed=Mod[Floor[AbsoluteTime[]*1000000],1000000]];
        SeedRandom[seed];
        regmargin = RegMargin/.{opts}/.Options[PrSAT];
        If[runquiet===True,
          PrintLog=Gobble,
          PrintLog=Print
          ];
        solved=False;
        (************Add Definedness Conditions For All Conditional Probabilities in Input Set***********)
        l=Defns[lfix[l0]];
		(*PrintLog["initial constraint set",l];*)
        (************INITIALIZE VARIABLE SETS***********)
        eventVariables=Sort[ExtractVariables[l]];
        eventSets=AssociateEventsWithAtoms[eventVariables];
        omega=\[CapitalOmega]/.eventSets;
        atomsInNonNullEvents=Complement[omega,NullEvent/.eventSets];
        nullEventRule=((NullEvent/.eventSets)[[1\
]]->1-Plus@@atomsInNonNullEvents)/.eventSets;
        PrintLog["Event variables: ",eventVariables];
        PrintLog["Event sets: ",eventSets];
        PrintLog["Null event rule: ", nullEventRule];
        (****PUT CONSTRAINTS IN THE PROPER FORM****)
        
        constrnts=constrnts /.eventSets//.
            {
              x_List&&y_List:>Intersection[x,y],
              x_List||y_List:>Union[x,y],
              Not[x_List]:>Complement[omega,x]
              }//.nullEventRule;
        (**********SET sys TO BE THE SYSTEM, 
          NOW USING VARIABLE SETS (REMOVE NULLEVENT)*****)
        
        sys=l/.eventSets//.{
              x_List&&y_List:>Intersection[x,y],
              x_List||y_List:>Union[x,y],
              Not[x_List]:>Complement[omega,x]
              }//.nullEventRule;
        PrintLog["Original system, after substitution of event variables: ",
          sys];
        
        (*********PUT sys IN NICE FORM: NO FRACTIONS, 
          AND BROKEN INTO AS MANY SEPARATE CLAUSES AS POSSIBLE***)
        (***
              BBBBBBBB  START OF PROBLEM LINE **)
        sys=sys//.{
              Inequality:>List,
              a_<b_<c__:>a<b&&b<c,
              a_>b_>c__:>a>b&&b>c,
              {x_,(h:Less|LessEqual|Greater|GreaterEqual),
                  y_,(h2:Less|LessEqual|Greater|GreaterEqual),
                  z__}:>h[x,y]&&{y,h2,z},
              {x_,(h:Less|LessEqual|Greater|GreaterEqual),y_}:>h[
                  x,y]
              };
        (*END OF PROBLEM LINE*)
        
        sys=CrossMultiply[
            FixedPoint[Flatten[Replace[#,And[x_,y_]->List[x,y],1]]&,sys],
            prc[omega,omega,regmargin]];
        PrintLog["System after cross multiplication and ANDs removed: ", 
          sys];
        (*******SOLVE THE EQUATIONS, KEEP REAL SOLUTIONS**********)
        
        equations=ExtractEquations[sys];
        PrintLog["Selected equations: ",ExtractEquations[l]];
        realonly[x_]:=!MemberQ[ExtractVariables[x] //. (x //. NonrealRule), Nonreal];
        PrintLog["Selected equations after substitution: ",equations];
        Off[Solve::svars];
		solve[x_]:=If[Head[Solve[x]]===Solve,{ToRules[Reduce[x]]},Solve[x]];
        sol1=
          If[equations!={},
            Select[Simplify[solve[equations],(And@@(0<=#<=1&/@ExtractVariables[equations]))&&Plus@@ExtractVariables[equations]<=1],realonly[#]&],{{}}];
        PrintLog["Solved equations: ",sol1];
        If[equations!={}&&sol1==={},Throw[{}];];
        (*****DON'T WORRY ABOUT MINIMIZATION ERRORS****)
        If[!bypass,
          Off[Power::infy];
          Off[\[Infinity]::indet];
          Off[NMinimize::cvmit];
          Off[NMinimize::nosat];
          Off[NMinimize::incst];
          Off[NMinimize::nnum];
          Off[NMinimize::nsol];
          Off[NMinimize::lvar];
          Off[NMinimize::nnum];
		  Off[NMinimize::bcons];
		  Off[Less::nord];
		  Off[Greater::nord];
          (***TRY <repeats> DIFFERENT OPTIMIZATION RUNS***)
          
          For[j=1,j<=repeats&&!solved,j++,
            i=0;
            sysIneqs=ExtractInequalities[sys];
            (*****FOR EVERY SOLUTION SET, SUBSTITUTE IT IN AND SOLVE*******)
 
                       While[!solved\[And]i<Length[sol1],
              i++;
              (*******BUILD SYSTEM FOR THIS SOLUTION SET******)
              
              systemToInstantiate=
                CrossMultiply[sysIneqs//.sol1[[i]],
                  prc[omega,omega,regmargin]];
              
              PrintLog["System for solution set ", i, ": ",
                systemToInstantiate];
              (***IF IT'S UNSATISFIABLE, TRY NEXT EQ SOLUTION****)
           
                 If[MemberQ[systemToInstantiate,False],Continue[]];
              (*****IF INEQUALITIES ARE NOW VACUOUSLY TRUE*****)
             
               If[systemToInstantiate==={True}||systemToInstantiate==={},
                (***GIVE A VACUOUS OBJECTIVE FUNCTION****)
                
                f=-1,
                systemToInstantiate = Simplify[systemToInstantiate/.{
                        x_!=y_->-((x)-(y))^2+margin^2,
                        x_>y_->margin+(y)-(x),
                        x_<y_->margin+(x)-(y),
                        x_>=y_->(y)-(x),
                        x_<=y_->(x)-(y),
                        (****Hopefully no equations will be left, 
                          but just in case, 
                          we try to minimize their violation.  
                              Not sure if the second argument should be 0 or \
a small threshold.***)
                        
                        x_==y_->ZeroJump[((x)-(y))^2,0]
                        }];
                f=(And@@systemToInstantiate)//.{
                      And->Max,
                      Or->Min
                      }
                ];
              PrintLog["Functions to minimax: ", f];
              (*****CONSTRAINTS: VARS ARE ALL PROBS******)
              
              sysCons=Simplify[
                  Union[CrossMultiply[
                      prc[atomsInNonNullEvents,omega,regmargin]//.sol1[[i]],
                      prc[omega,omega,regmargin]
                      ]]];
            (*PrintLog["first term of constraints",prc[atomsInNonNullEvents,omega,regmargin]];*)
				PrintLog["Constraints: ",sysCons];
              (******STARTING OPTIMIZATION POINTS: RANDOM******)
             
               modelvars=
                ExtractVariables[systemToInstantiate\[Union]sysCons];
              nonmodelvars=Complement[omega,modelvars];
              
              initPoint=
                Take[RandomModel[
                    Length[modelvars]+Length[nonmodelvars]],
                  Length[modelvars]];
              (*****STARTING OPTIMIZATION RANGES: 
                    box with diagonally opposite corners p and p/
                        2 for each initpoint p.  
                        I have no idea if this is the best way to do this.*******)

                            
              initRange=MapThread[{#1,#2/2.,#2}&,{modelvars,initPoint}];
              (*****NM method seems to work well, 
                but we may eventually want to allow others***)
              
              solved=False;
              PrintLog["Initial search range: ", {modelvars,initRange}];
              If[Length[modelvars]>0,
                If[method=="NM",
                  PrintLog[f,sysCons,initRange];
                  
                  model=NMinimize[{f,sysCons},initRange,
                      "RandomSeed"->seed+i*100+j*10000],
                  If[method=="Random",
                    (****DOESN'T SEEM TO WORK--BEST TO STICK TO NM****)
      
                                  model=NMinimize[{f,sysCons},modelvars,
                        
                        Method->{"RandomSearch",
                            "InitialPoints"->{initPoint},
                            "SearchPoints"->1}],
                    Message[PrSAT::badmeth];
                    Return[{}]
                    ]
                  ],
                model={-1,{}}];
              PrintLog["Trial ",j," yielded model ", model];
              If[model[[1]] < 0,                
              nonmodelvars = Complement[omega,modelvars];
                
                nonmodelvarvals = 
                  nonmodelvars//.Join[{nullEventRule},model[[2]],sol1[[i]]];
                
                nonmodelvarrules = 
                  MapThread[(#1->#2)&,{nonmodelvars,nonmodelvarvals}];
                solutionLists={Sort[Join[model[[2]], nonmodelvarrules]]};
                (****IF THE MODEL AS RETURNED FROM NMINIMIZE DOES WORK, 
                  RATIONALIZE IT AND RETURN***)
                
                testmodel=Join[
                    {Join[#->(#/.eventSets)&/@
                          eventVariables,{\[CapitalOmega]->omega}]},
                    solutionLists
                    ];
                
                If[And@@Verify[l,testmodel,
                        Probabilities->(Probabilities/.{opts}/.Options[
                                PrSAT])][[1]],
                  (*****RATIONALIZE MODEL AND SUB IN SOLVED VARS***)
         
                           diff=regmargin/2;
                  While[!solved,
                    ratmodel = Rationalize[model[[2]],diff];
                    
                    nonmodelvarvals =
                      Simplify[ 
                        nonmodelvars//.Join[{nullEventRule},ratmodel,
                            sol1[[i]]]];
                    
                    nonmodelvarrules = 
                      MapThread[(#1->#2)&,{nonmodelvars,
                          nonmodelvarvals}];
                    ratmodel = Sort[Join[ratmodel, nonmodelvarrules]];
                    solutionLists={ratmodel};
                    ratmodel=Join[
                        {Join[#->(#/.eventSets)&/@
                              eventVariables,{\[CapitalOmega]->omega}]},
                        solutionLists
                        ];
                    
                    PrintLog["Rationalizing. Diff ",diff,"  Model: ", 
                      ratmodel];
                    
                    certificate=
                      Simplify[
                        Verify[l,ratmodel,
                          Probabilities->(Probabilities/.{opts}/.Options[
                                  PrSAT])]];
                    PrintLog["Constraints satisfied: ",certificate];
                    
                    If[And@@certificate[[1]]===True, (*Necessary, stupidly*)
 
                                           solved=True;
                      PrintLog["solved! ",diff],
                      diff = diff/2;
                      PrintLog["didn't solve! ",diff];
                      ]
                    ],PrintLog["Test Model didn't satisfy system"]
                  ]
                ]
              ]
            ];
          (******NOW WE'VE DONE THE OPTIMIZATION.  IF IT'S NOT GOOD ENOUGH, 
            ON TO PrSAT**)
          PrintLog["Model: ",model];
          ];
        If[!solved,
          (************************************************)
          
          If[!findinst,Return[{}]];
          i=0;
          sol[i]={};
          sys=sys\[Union]constrnts;
          If[!bypass,Message[PrSAT::srchfail]];
          While[sol[i]==={}\[And]i<Length[sol1],
            i++;
            ineqs1[i]= If[ExtractInequalities[sys]==={},
						Simplify[prc[ExtractVariables[sys],omega,0]\[Union]sys //.sol1[[i]]],
						prc[ExtractVariables[sys],omega,0]\[Union]ExtractInequalities[sys]//.sol1[[i]]];
            PrintLog["Ineqs: ",ineqs1[i]];

            eqsz=MapThread[
                Equal[#1,#2]&,{ExtractVariables[
                    sol1[[i]]],(ExtractVariables[
                        sol1[[i]]]//.sol1[[i]])}];
            PrintLog["Eqsz: ",eqsz];
            
            sysz=Simplify[If[And@@Flatten[{ineqs1[i]}]===True,And@@prc[ExtractVariables[sys],omega,0]//.sol1[[i]],
                If[ineqs1[i]==={},False,And@@ineqs1[i]//.sol1[[i]]]]];
            
            PrintLog["System of inequalities to ship to FindInstance: ",
              sysz];
            If[sysz===False,
              PrintLog["Continuing"];
              sol[i]={};
              modelb[i]=False;
              Continue[]
              ];
            vars=Sort[ExtractVariables[sysz]];
            PrintLog["Variables in system: ",vars];
            sol[i]=FindInstance[sysz,vars,Reals];
            PrintLog["Output of FindInstance: ",sol[i]];
            
            model1[i]=
              Simplify[bootstrap[Select[Flatten[Join[sol1[[i]]//.sol[i],sol[i]]],Not[MatchQ[#,x_->x_]]&]]];
			
            PrintLog["model1[",i,"]: ",model1[i]];
            
            nextSystem=
              And@@prc[omega,omega,0]&&And@@sys//.model1[i];
            PrintLog["nextSystem: ",nextSystem];

			If[nextSystem===False,
              PrintLog["Continuing"];
              sol[i]={};
              modelb[i]=False;
              Continue[]
              ];
			model2[i]=
              FindInstance[nextSystem,ExtractVariables[nextSystem]];
            If[model2[i]=={},
              modelb[i]=False,
              modelb[i]=Sort[Join[model1[i],model2[i]]]
              ];
            PrintLog["modelb[i]: ",modelb[i]];
            ]; (* End of WHILE Loop*)
          Off[Flatten::normal];
          If[sol1==={},
            ms={},
            
            ms=(Sort/@Flatten/@Table[modelb[i],{i,1,Length[sol1]}])//.Flatten[
                    False]-> False
            ];
          If[Or@@ms===False,
            Return[{}],
            solutionLists=Select[ms,ListQ];
            ]
          ];
        Return[
          Join[
            {Join[#->(#/.eventSets)&/@
                  eventVariables,{\[CapitalOmega]->omega}]},
            solutionLists
            ]
          ]
        ]
      ];

Options[Verify]={ShowStages->Last,Probabilities->NotRegular};

Verify[l_,sol_,opts___]:=Module[{omega,r,s1,s2,stgs,prc},
    prc=Probabilities/.{opts}/.Options[
          Verify];
    If[prc===NotRegular,
      prc=NotRegular,
      If[prc===Regular,
        prc=Regular,
        Message[PrSAT::err1];
        prc=NotRegular
        ]
      ];
    stgs=ShowStages/.{opts}/.Options[Verify]/.Last->-1;
    omega=\[CapitalOmega]/.sol[[1]];
    s1=Join[l,
          prc[omega,omega,0]]/.sol[[1]];
    s2=s1//.{
          x_List&&y_List:>Intersection[x,y],
          x_List||y_List:>Union[x,y],
          Not[x_List]:>Complement[omega,x]
          };
    If[IntegerQ[stgs]===
          True&&(1<=stgs<=4||-4<=
              stgs<=-1),
      Return[
        Simplify[
          Take[{l,s1,s2,s2/.sol[[2]]},
            stgs]]],
      Return[
        Simplify[{l,s1,s2,
            s2/.sol[[2]]}]]
      ]
    ]

EvaluateProbability[e1_,sol_]:=Module[{e,omega},
	e = lfix[e1];
    omega=\[CapitalOmega]/.sol[[1]];
    (e/.sol[[1]])//.{
            x_List&&y_List:>Intersection[x,y],
            x_List||y_List:>Union[x,y],
            Not[x_List]:>Complement[omega,x]
            }/.sol[[2]]/.{Pr[True]->1}//Return;
    ]

PrKey[s_] := Module[{v1, v2, v3, v4, sds, mod, tt}, v1 = ExtractVariables[s]; 
     v2 = Not /@ v1; v3 = Union[v1, v2]; 
     v4 = Select[Select[Union /@ Union[Sort /@ Tuples[v3, Length[v1]]], 
        Length[#1] == Length[v1] & ],  !TautologyQ[And @@ #1 \[Equivalent] False] & ]; 
     sds = (And @@ #1 & ) /@ v4; mod = PrSAT[(Pr[#1] == 1/Length[sds] & ) /@ 
        sds]; TruthTable[mod]]; 

PrReduce[s_] := Module[{vars,pr,sys,f},
sys[S_]:=AlgebraicForm[S,ExtractVariables[S]];
vars[S_]:=ExtractVariables[S];
pr[S_]:=And@@(0<=#1<=1&)/@vars[S]&&Plus@@vars[S]<=1;
f[S_]:=FullSimplify[Reduce[pr[S]&&S],pr[S]];
FixedPoint[f,sys[s],4]];

PrSolve[s_] := Module[{sys,pr,vars},
sys:=AlgebraicForm[s,ExtractVariables[s]];
vars:=ExtractVariables[sys];
pr:=And@@(0<=#1<=1&)/@vars&&Plus@@vars<=1;
FullSimplify[Solve[sys],pr]];

PrFullSimplify[s_] := Module[{vars,pr,sys},
sys:=AlgebraicForm[s,ExtractVariables[s]];
vars:=ExtractVariables[sys];
pr:=And@@(0<=#1<=1&)/@vars&&Plus@@vars<=1;
FullSimplify[pr&&sys,pr]];

PrRange[prexpr_, cons_] := Module[{vars1, vars2}, 
    vars1 = Union[ExtractVariables[prexpr], ExtractVariables[cons]]; 
     vars2 = VARS[vars1]; {Minimize[{AlgebraicForm[prexpr, vars1], 
         pr[vars1] && AlgebraicForm[cons, vars1]}, vars2][[1]], 
      Maximize[{AlgebraicForm[prexpr, vars1], pr[vars1] && 
          AlgebraicForm[cons, vars1]}, vars2][[1]]}]; 

PrGraph[model_, prps_] := Module[{vars, SDs, tt, am, props, equiv, PPs, G, allpairs, GF, 
     GS}, vars[m_] := Drop[Flatten[m[[1]]] //. (x_ -> y_) :> x, -1]; 
     tt[m_] := Flatten[Outer[List, Sequence @@ Table[{True, False}, {Length[vars[m]]}]], 
       Length[vars[m]] - 1]; SDs[m_] := (And @@ #1 & ) /@ 
       (Table[If[#1[[i]] === True, vars[m][[i]],  !vars[m][[i]]], 
          {i, 1, Length[vars[m]]}] & ) /@ tt[m]; 
     props[m_] := props[m] = (Or @@ #1 & ) /@ Take[Subsets[SDs[m]], 
         {2, Length[Subsets[SDs[m]]] - 1}]; am[m_, i_, j_] := 
      am[m, i, j] = EvaluateProbability[Pr[props[m][[i]]] <= Pr[props[m][[j]]], m]; 
     equiv[p_, P_, i_] := equiv[p, P, i] = LogicalExpand[Implies[p, P[[i]]] && 
          Implies[P[[i]], p]] === True; PPs[m_] := 
      PPs[m] = Flatten[Position[(Or @@ #1 & ) /@ Table[equiv[props[m][[i]], prps, j], 
           {i, 1, Length[props[m]]}, {j, 1, Length[prps]}], True]]; 
     allpairs[m_] := allpairs[m] = Flatten[Table[If[am[m, i, j] === True, i -> j, {}], 
         {i, 1, Length[props[m]]}, {j, 1, Length[props[m]]}]]; 
     GF[m_] := GF[m] = Graph[allpairs[m]]; GS[m_, ps_] := 
      GS[m, ps] = Subgraph[GF[m], PPs[m]]; If[prps === All, GF[model], GS[model, prps]]]; 

Protect[
    All,
    EvaluateProbability,
    Last,
    NotRegular,
    PrSAT,
    Probabilities,
    Constraints,
    RunQuietly,
    Regular,
    ShowStages,
    Verify,
    AlgebraicForm,
    TruthTable,
    PrKey,
    PrReduce,
	PrReduceFast,
	PrFullSimplify,
	PrSolve,
	PrGraph,
	pr,
	prR,
	PR,
	PRR
    ];
